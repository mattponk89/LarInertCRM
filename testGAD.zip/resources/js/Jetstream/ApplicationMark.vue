<template>
  <img :src="'/images/LOGO2.jpg'" alt="logo">
</template>
