<template>
    <inertia-link :href="'/'">
        <img src="images/LOGO2.jpg" alt="logo">
    </inertia-link>
</template>
